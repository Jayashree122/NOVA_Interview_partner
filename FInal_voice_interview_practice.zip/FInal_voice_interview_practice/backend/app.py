# app.py
import os
import uuid
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from utils import save_upload_tempfile, cleanup_file
from stt import transcribe_audio, stt_ready
from interview_logic import InterviewManager
from llm import generate_answer, check_ollama
from tts_elevenlabs import synthesize_audio_bytes, tts_ready

app = FastAPI(title="Interview Practice Partner (Voice)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static frontend
static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
if os.path.isdir(static_dir):
    app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

manager = InterviewManager()

@app.get("/health")
def health():
    return {
        "status": "ok",
        "stt_ready": stt_ready(),
        "ollama_reachable": check_ollama(),
        "tts_ready": tts_ready()
    }

@app.post("/interview/start")
def start_interview(role: str = Form(...)):
    manager.start(role)
    return {"message": f"Interview started for role: {role}"}

@app.post("/interview/ask")
def ask_text(text: str = Form(...)):
    """Text chat mode"""
    ai_text = manager.process_user_answer(text)
    return {"response": ai_text}

@app.post("/interview/voice")
async def interview_voice(audio: UploadFile = File(...)):
    """
    Receive recorded audio file (webm/wav/ogg).
    Steps:
      1) Save upload
      2) STT -> text
      3) Process via interview manager / LLM
      4) Synthesize audio via ElevenLabs -> return audio bytes as wav
    """
    tmp_in = save_upload_tempfile(audio)
    try:
        # 1) STT
        user_text = transcribe_audio(tmp_in)

        # 2) Interview logic (calls LLM)
        ai_text = manager.process_user_answer(user_text)

        # 3) TTS -> return bytes as file response
        audio_bytes = synthesize_audio_bytes(ai_text)
        tmp_out = f"out_{uuid.uuid4().hex}.wav"
        with open(tmp_out, "wb") as f:
            f.write(audio_bytes)

        headers = {"X-AI-Text": ai_text}
        return FileResponse(tmp_out, media_type="audio/wav", headers=headers)
    except Exception as e:
        return JSONResponse({"error": "processing_failed", "detail": str(e)}, status_code=500)
    finally:
        cleanup_file(tmp_in)
