# llm.py
import os
import requests

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")

def check_ollama(timeout: float = 2.0) -> bool:
    try:
        r = requests.get(f"{OLLAMA_URL}/api/status", timeout=timeout)
        return r.ok
    except Exception:
        return False

def generate_answer(prompt: str, model: str = "llama3") -> str:
    """
    Call local Ollama API to generate text. If not available, returns a heuristic fallback.
    """
    try:
        url = f"{OLLAMA_URL}/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "max_tokens": 400,
            "temperature": 0.2
        }
        r = requests.post(url, json=payload, timeout=15)
        r.raise_for_status()
        j = r.json()
        if isinstance(j, dict) and "response" in j:
            return j["response"]
        # try some common keys
        for k in ("text", "generated_text", "output"):
            if k in j:
                return j[k]
        return str(j)
    except Exception:
        return fallback_response(prompt)

def fallback_response(prompt: str) -> str:
    # Simple fallback: produce feedback + follow-up
    feedback = "Good start. Improve by giving a clearer structure (Situation, Task, Action, Result) and add measurable outcomes."
    follow_up = "FOLLOW-UP: Can you provide a specific example with numbers/results?"
    return f"{feedback}\n\n{follow_up}"
