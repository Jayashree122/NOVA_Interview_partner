# interview_logic.py
from llm import generate_answer

class InterviewManager:
    def __init__(self):
        self.role = None
        self.questions = []
        self.index = 0

    def start(self, role: str = "software engineer"):
        self.role = role.lower()
        self.index = 0
        templates = {
            "software engineer": [
                "Tell me about yourself and your background in software engineering.",
                "Describe a technically challenging project you worked on. What was your role?",
                "Explain a bug or production incident you handled and how you fixed it.",
                "How do you design systems for scale? Walk me through an example."
            ],
            "data analyst": [
                "Tell me about a dataset you worked with and the impact of your analysis.",
                "How do you handle missing or corrupted data?",
                "Describe a visualization that influenced a stakeholder.",
                "Explain an A/B test you designed or interpreted."
            ],
            "sales": [
                "Tell me about a time you closed a difficult sale.",
                "How do you handle objections from a prospective client?",
                "Describe your sales process from prospecting to close.",
                "Give an example of exceeding sales targets and how you did it."
            ],
            "general": [
                "Tell me about yourself.",
                "What are your strengths and weaknesses?",
                "Why do you want to work here?",
                "Describe a professional challenge and how you overcame it."
            ]
        }
        self.questions = templates.get(self.role, templates["general"])

    def process_user_answer(self, user_answer: str) -> str:
        if self.index >= len(self.questions):
            return "Interview complete. Thank you — do you want feedback or a summary of your answers?"

        current_q = self.questions[self.index]
        prompt = (
            f"You are an interviewer for a {self.role} role.\n"
            f"Question: {current_q}\n\n"
            f"Candidate answer: {user_answer}\n\n"
            "Tasks:\n"
            "1) Give brief feedback on the candidate's answer (communication, technical depth, structure).\n"
            "2) Provide a concise follow-up question or next interview question.\n"
            "Respond in plain text with a short feedback paragraph, then 'FOLLOW-UP:' and the follow-up question.\n"
        )
        ai_text = generate_answer(prompt)
        self.index += 1
        return ai_text
