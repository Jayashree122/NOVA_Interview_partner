# tts_elevenlabs.py
import os
from elevenlabs import set_api_key, generate, Voices, voice
from elevenlabs import save, stream  # depending on SDK version

ELEVEN_API_KEY = os.environ.get("ELEVENLABS_API_KEY")
if ELEVEN_API_KEY:
    set_api_key(ELEVEN_API_KEY)

def tts_ready():
    return ELEVEN_API_KEY is not None

def synthesize_audio_bytes(text: str, chosen_voice: str = "alloy") -> bytes:
    """
    Generate spoken audio bytes (wav) from text using ElevenLabs.
    chosen_voice can be a voice id/name available in your account.
    Returns raw audio bytes (wav or mp3 depending on ElevenLabs settings).
    """
    if not ELEVEN_API_KEY:
        raise RuntimeError("ELEVENLABS_API_KEY not configured in environment")

    # The 'generate' method signature depends on elevenlabs SDK version.
    # Use a simple pattern that works with common versions:
    audio = generate(text=text, voice=chosen_voice, model="eleven_multilingual_v2")
    # 'audio' returned is typically bytes-like.
    return audio
