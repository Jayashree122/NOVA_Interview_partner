# stt.py
import os
from faster_whisper import WhisperModel

# Choose model size: tiny, base, small, medium, large (larger needs more resources)
MODEL_SIZE = os.environ.get("FAST_WHISPER_MODEL", "small")  # small recommended for dev
_device = "cpu"  # or "cuda" if you have GPU

_model = None

def stt_ready():
    try:
        _ = get_model()
        return True
    except Exception:
        return False

def get_model():
    global _model
    if _model is None:
        # model will be downloaded/stored under HF cache
        _model = WhisperModel(MODEL_SIZE, device=_device, compute_type="int8")  # int8 reduces memory
    return _model

def transcribe_audio(path: str) -> str:
    """
    Transcribe audio using faster-whisper and return the text.
    Supports wav/webm/ogg/mp3.
    """
    model = get_model()
    segments, info = model.transcribe(path, beam_size=5)
    # collect segments into text
    text = " ".join([segment.text for segment in segments]).strip()
    return text
