// script.js
const startBtn = document.getElementById('startBtn');
const roleSel = document.getElementById('role');
const recordBtn = document.getElementById('record');
const status = document.getElementById('status');
const transcript = document.getElementById('transcript');
const assistant = document.getElementById('assistant');
const log = document.getElementById('log');

let mediaRecorder, chunks = [];

startBtn.onclick = async () => {
  const role = roleSel.value;
  await fetch('/interview/start', { method: 'POST', body: new URLSearchParams({ role }) });
  status.innerText = 'Interview started for ' + role;
};

recordBtn.onclick = async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    recordBtn.innerText = 'Start Recording';
    return;
  }

  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  mediaRecorder = new MediaRecorder(stream);
  chunks = [];
  mediaRecorder.ondataavailable = e => chunks.push(e.data);
  mediaRecorder.onstop = async () => {
    status.innerText = 'Uploading audio...';
    const blob = new Blob(chunks, { type: 'audio/webm' });
    const fd = new FormData();
    fd.append('audio', blob, 'speech.webm');

    // STT + generate + tts happens on /interview/voice
    const resp = await fetch('/interview/voice', { method: 'POST', body: fd });
    if (!resp.ok) {
      const j = await resp.json();
      status.innerText = 'Error: ' + (j.detail || j.error);
      return;
    }
    const aiText = resp.headers.get('X-AI-Text') || '';
    transcript.innerText = 'You: (audio submitted)';
    assistant.innerText = aiText || 'Assistant responded';
    status.innerText = 'Playing audio...';

    const audioBlob = await resp.blob();
    const url = URL.createObjectURL(audioBlob);
    const a = new Audio(url);
    a.play();
    a.onended = () => { status.innerText = 'Ready'; }
  };

  mediaRecorder.start();
  recordBtn.innerText = 'Stop Recording';
  status.innerText = 'Recording...';
};
